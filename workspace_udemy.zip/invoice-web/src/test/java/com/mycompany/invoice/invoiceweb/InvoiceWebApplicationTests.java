package com.mycompany.invoice.invoiceweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import javax.sql.DataSource;

@SpringBootTest
@EntityScan("com.mycompany.invoice.core.model.*")
class InvoiceWebApplicationTests {

	@Test
	void contextLoads() {
	}


}

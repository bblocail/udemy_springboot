package com.mycompany.invoice.invoiceweb.api;


import com.mycompany.invoice.core.model.Invoice;
import com.mycompany.invoice.core.service.IInvoiceService;
import com.mycompany.invoice.invoiceweb.form.InvoiceForm;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/invoice")
@ComponentScan(basePackages = {"com.mycompany.invoice.core"})
public class InvoiceResource {


    @Autowired
    private IInvoiceService invoiceService;

    @PostMapping("")
    public Invoice createInvoice( @RequestBody Invoice invoice){
        invoiceService.createInvoice(invoice);
        return invoice;
    }


    @GetMapping
    public  Iterable<Invoice> listInvoices(Model model){
        System.out.println("La méthode listInvoices a été invoquée");
        return invoiceService.list();
    }



    @GetMapping("/{id}")
    public  Invoice  getInvoice(@PathVariable("id") String number){
        System.out.println("La méthode displayInvoice a été invoquée");
        return  invoiceService.getInvoiceByNumber(number);
    }
/*
@GetMapping("/create-form")
    public String displayInvoiceCreateForm(@ModelAttribute InvoiceForm invoice){
        return "invoice-create-form";
    }
*/
    public IInvoiceService getInvoiceService() {
        return invoiceService;
    }

    public void setInvoiceService(IInvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }
}

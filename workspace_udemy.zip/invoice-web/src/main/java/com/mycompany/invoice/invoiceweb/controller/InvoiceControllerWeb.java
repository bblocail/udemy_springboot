package com.mycompany.invoice.invoiceweb.controller;


import com.mycompany.invoice.core.controller.IIInvoiceController;
import com.mycompany.invoice.core.model.Invoice;
import com.mycompany.invoice.core.service.IInvoiceService;
import com.mycompany.invoice.invoiceweb.form.InvoiceForm;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;


@Controller
@RequestMapping("/invoice")
public class InvoiceControllerWeb {



    @Autowired
    private IInvoiceService invoiceService;

    @PostMapping("/create")
    public String createInvoice(@Valid @ModelAttribute InvoiceForm invoiceForm, BindingResult result){
       if(result.hasErrors()){
           return "invoice-create-form";
       }

        Invoice invoice = new Invoice();
        invoice.setCustomerName(invoiceForm.getCustomerName());
        invoice.setOrderNumber(invoiceForm.getOrderNumber());
        invoiceService.createInvoice(invoice);
        return "invoice-created";
    }


/*
    @RequestMapping("/home")
    public ModelAndView displayHome(){
        System.out.println("La méthode displayHome a été invoquée");
        List<Invoice> invoices = invoiceService.list();
        ModelAndView mv = new ModelAndView("invoice-home");
        mv.addObject("invoices",invoices);
        return mv;
    }



    @RequestMapping("/{id}")
    public ModelAndView  displayInvoice(@PathVariable("id") String number){
        System.out.println("La méthode displayInvoice a été invoquée");
        Invoice invoice = invoiceService.getInvoiceByNumber(number);
        ModelAndView mv = new ModelAndView("invoice-details");
        mv.addObject("invoice",invoice);
        return mv;
    }
    */

    @GetMapping("/home")
    public String displayHome(Model model){
        System.out.println("La méthode displayHome a été invoquée");
        Iterable<Invoice> invoices = invoiceService.list();
        model.addAttribute("invoices",invoices);
        return "invoice-home";
    }


/*
    @GetMapping("/{id}")
    public String  displayInvoice(@PathVariable("id") String number,Model model){
        System.out.println("La méthode displayInvoice a été invoquée");
        Invoice invoice = invoiceService.getInvoiceByNumber(number);
        model.addAttribute("invoice",invoice);
        return "invoice-details";
    }
*/
@GetMapping("/create-form")
    public String displayInvoiceCreateForm(@ModelAttribute InvoiceForm invoice){
        return "invoice-create-form";
    }

    public IInvoiceService getInvoiceService() {
        return invoiceService;
    }

    public void setInvoiceService(IInvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }
}

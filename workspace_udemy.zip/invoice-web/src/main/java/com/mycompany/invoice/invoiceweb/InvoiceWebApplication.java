package com.mycompany.invoice.invoiceweb;

import com.mycompany.invoice.core.model.Invoice;
import com.mycompany.invoice.core.repository.IInvoiceRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;


@SpringBootApplication
/*
@EnableJpaRepositories
@ComponentScan(basePackages = {"com.mycompany.invoice.core.repository","com.mycompany.invoice.invoiceweb.controller","com.mycompany.invoice.core.service"})
*/
@ComponentScan(basePackages = {"com.mycompany.invoice.core.repository"})
@EntityScan("com.mycompany.invoice.core.model.*")
public class InvoiceWebApplication {


	public static void main(String[] args) {
		//SpringApplication.run(InvoiceWebApplication.class, args);


		ApplicationContext context = SpringApplication.run(InvoiceWebApplication.class, args);

		DataSource ds = context.getBean(DataSource.class);
		Connection conn = null;
		try{
			conn = ds.getConnection();
			System.out.println("Connected!");
			ResultSet rs = conn.createStatement().executeQuery("SELECT INVOICE_NUMBER,CUSTOMER_NAME,ORDER_NUMBER FROM INVOICE");
			while(rs.next()){
				System.out.println(rs.getLong("INVOICE_NUMBER") + "|" + rs.getString("CUSTOMER_NAME")+ "|" + rs.getString("ORDER_NUMBER"));
			}
		}
		catch(SQLException e){
			e.printStackTrace();;
		}
		finally{
			try{
				if(conn!= null){
					conn.close();
				}
			}catch(SQLException e){
				e.printStackTrace();;
			}

		}

/*

		IInvoiceRepository repository = context.getBean(IInvoiceRepository.class);

		Iterable<Invoice>  invoices = repository.findAll();

		invoices.forEach(invoice -> System.out.println(invoice.toString()));
*/


	}

}

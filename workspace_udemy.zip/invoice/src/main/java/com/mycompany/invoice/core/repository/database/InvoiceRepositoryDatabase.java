package com.mycompany.invoice.core.repository.database;
/*
import com.mycompany.invoice.core.model.Invoice;
import com.mycompany.invoice.core.repository.IInvoiceRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class InvoiceRepositoryDatabase implements IInvoiceRepository {


    public Invoice create(Invoice invoice){



        //invoices.add(invoice);

        System.out.println("Database : Invoice : " + invoice.getNumber() +" added for " + invoice.getCustomerName());
        return invoice;
    }


    public List<Invoice> list(){

        Invoice invoice1 = new Invoice();
        invoice1.setNumber("NUM_1");
        invoice1.setCustomerName("APPLE CORPORATION");

        Invoice invoice2 = new Invoice();
        invoice2.setNumber("NUM_2");
        invoice2.setCustomerName("IBM CORPORATION");

        Invoice invoice3 = new Invoice();
        invoice3.setNumber("NUM_3");
        invoice3.setCustomerName("GOOGLE CORPORATION");

        Invoice invoice4 = new Invoice();
        invoice4.setNumber("NUM_4");
        invoice4.setCustomerName("FACEBOOK CORPORATION");

        return  List.of(invoice1,invoice2,invoice3,invoice4);
    }

    public Invoice getById(String number){
        Invoice invoice = new Invoice();
        invoice.setNumber(number);
        invoice.setCustomerName("APPLE CORPORATION");
        invoice.setOrderNumber("ON_002");
        return invoice;
    }

}
*/
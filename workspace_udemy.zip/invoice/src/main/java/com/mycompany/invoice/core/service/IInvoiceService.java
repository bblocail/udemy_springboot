package com.mycompany.invoice.core.service;

import com.mycompany.invoice.core.model.Invoice;
import com.mycompany.invoice.core.repository.IInvoiceRepository;

import java.util.List;

public interface IInvoiceService {
    Invoice createInvoice(Invoice invoice);
    void setInvoiceRepository(IInvoiceRepository invoiceRepository);

    Invoice getInvoiceByNumber(String number);

    Iterable<Invoice> list();
}

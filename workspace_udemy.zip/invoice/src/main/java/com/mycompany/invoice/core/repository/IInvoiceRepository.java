package com.mycompany.invoice.core.repository;

import com.mycompany.invoice.core.model.Invoice;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IInvoiceRepository extends CrudRepository<Invoice,String> {

}

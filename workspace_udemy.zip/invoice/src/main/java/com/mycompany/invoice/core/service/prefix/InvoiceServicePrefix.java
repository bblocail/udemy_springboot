package com.mycompany.invoice.core.service.prefix;

import com.mycompany.invoice.core.model.Invoice;
import com.mycompany.invoice.core.repository.IInvoiceRepository;
import com.mycompany.invoice.core.service.IInvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
public class InvoiceServicePrefix implements IInvoiceService {
    @Value("${invoice.lastNumber}")
    private  Long lastNumber;
    @Value("${invoice.prefix}")
    private String prefix;


    public long getLastNumber() {
        return lastNumber;
    }

    public void setLastNumber(long lastNumber) {
        this.lastNumber = lastNumber;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }


    @Autowired
    private IInvoiceRepository invoiceRepository;

    public Invoice createInvoice(Invoice invoice){
        invoice.setNumber( String.valueOf(prefix +(++lastNumber)));
        return invoiceRepository.save(invoice);
    }


    public Invoice getInvoiceByNumber(String number){
        return invoiceRepository.findById(number).orElseThrow();
    }

    public Iterable<Invoice> list(){

          Collection<Invoice> results = (Collection<Invoice>) invoiceRepository.findAll();
          System.out.println("Contenu DB : " + results.size());
          return results;

    }

    public IInvoiceRepository getInvoiceRepository() {
        return invoiceRepository;
    }

    public void setInvoiceRepository(IInvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }
}

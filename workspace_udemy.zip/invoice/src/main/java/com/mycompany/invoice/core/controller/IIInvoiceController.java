package com.mycompany.invoice.core.controller;

import com.mycompany.invoice.core.model.Invoice;
import com.mycompany.invoice.core.service.IInvoiceService;

public interface IIInvoiceController {
    String createInvoice(Invoice invoice);
    public void setInvoiceService(IInvoiceService invoiceService);
}

package com.mycompany.invoice.core.service.number;

import com.mycompany.invoice.core.model.Invoice;
import com.mycompany.invoice.core.repository.IInvoiceRepository;
import com.mycompany.invoice.core.service.IInvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

//@Service
public class InvoiceServiceNumber implements IInvoiceService {

    private static long lastNumber = 0;

    private IInvoiceRepository invoiceRepository ;

    public Invoice createInvoice(Invoice invoice){
        invoice.setNumber( String.valueOf(++lastNumber));
        return invoiceRepository.save(invoice);
    }

    public Invoice getInvoiceByNumber(String number){
        return invoiceRepository.findById(number).orElseThrow();
    }

    public Iterable<Invoice> list(){
        return  invoiceRepository.findAll();
    }

    public IInvoiceRepository getInvoiceRepository() {
        return invoiceRepository;
    }

    public void setInvoiceRepository(IInvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }
}

package com.mycompany.invoice.core.controller.keyboard;

import com.mycompany.invoice.core.controller.IIInvoiceController;
import com.mycompany.invoice.core.model.Invoice;
import com.mycompany.invoice.core.service.IInvoiceService;
import org.springframework.beans.factory.annotation.Autowired;


import java.util.Scanner;

//@Controller
public class InvoiceControllerKeyboard implements IIInvoiceController {
    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    @Autowired
    private IInvoiceService invoiceService;

    public String createInvoice(Invoice invoice){
        System.out.println( "Customer name :" );
        Scanner sc = new Scanner(System.in);
        String customerName = sc.nextLine();
        invoice = new Invoice();
        invoice.setCustomerName(customerName);
        invoiceService.createInvoice(invoice);
        return invoice.getNumber();
    }

    public IInvoiceService getInvoiceService() {
        return invoiceService;
    }

    public void setInvoiceService(IInvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }
}

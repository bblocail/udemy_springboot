package com.mycompany.invoice.core.controller.scan;

import com.mycompany.invoice.core.controller.IIInvoiceController;
import com.mycompany.invoice.core.model.Invoice;
import com.mycompany.invoice.core.service.IInvoiceService;
import org.springframework.beans.factory.annotation.Autowired;

//@Controller
public class InvoiceControllerDouchette implements IIInvoiceController {

    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    @Autowired
    private IInvoiceService invoiceService;

    public String createInvoice(Invoice invoice){
        System.out.println( "Usage of a scanner" );

        invoice = new Invoice();
        invoice.setCustomerName("Virgin Galactic");
        invoiceService.createInvoice(invoice);

        return invoice.getNumber();

    }

    public IInvoiceService getInvoiceService() {
        return invoiceService;
    }

    public void setInvoiceService(IInvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }
}
